import telebot
import requests
from bs4 import BeautifulSoup
api = '6594995717:AAGiMrwKQXGxlo2KVPKq1ocs3RsQx6VhwPs'
data = telebot.TeleBot(api)
@data.message_handler(commands=['start'])
def balas_start(message):
    data.reply_to(message,'Selamat Datang di Bot AAF')
@data.message_handler(commands=['scrap'])
def scrap(message):
    page = requests.get("https://plniconplus.co.id/e-proc/")
    after_bs = BeautifulSoup(page.content, 'html.parser')
    for area in after_bs.find_all('div',class_="post__detail"):
        judul = area.find('h3',class_="post__title").text
        tanggal = area.find('div',class_="post__date").text
        deskripsi = area.find('p').text
        link = area.find('a')['href'] 
        print('Judul :',judul)
        print('Pulbikasi :',tanggal) 
        print('Deskripsi :',deskripsi)
        print('Selengkapnya :',link)
        print("-----------")
    output = 'Percobaan'
    for x in judul, tanggal, deskripsi, link:      
        output = output + '\n' + x 
    data.reply_to(message, output)
print('Bot Berjalan')
data.polling()